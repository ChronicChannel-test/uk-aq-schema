-- Backfill ops metadata tables for Obs AQI DB.
-- Apply in Obs AQI DB (service_role context).
-- Canonical schema-repo file for backfill ledger objects.

create schema if not exists uk_aq_ops;

create table if not exists uk_aq_ops.backfill_runs (
  run_id uuid primary key,
  run_mode text not null check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels')),
  trigger_mode text not null check (trigger_mode in ('manual', 'scheduler')),
  window_from_utc date not null,
  window_to_utc date not null,
  connector_filter integer[],
  dry_run boolean not null default false,
  force_replace boolean not null default false,
  status text not null check (status in ('in_progress', 'ok', 'error', 'dry_run', 'stubbed')),
  rows_read bigint not null default 0,
  rows_written_aqilevels bigint not null default 0,
  objects_written_r2 bigint not null default 0,
  checkpoint_json jsonb,
  error_json jsonb,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists backfill_runs_started_at_idx
  on uk_aq_ops.backfill_runs (started_at desc);

create table if not exists uk_aq_ops.backfill_run_days (
  id bigserial primary key,
  run_id uuid not null references uk_aq_ops.backfill_runs(run_id) on delete cascade,
  run_mode text not null check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels')),
  day_utc date not null,
  connector_id integer not null,
  source_kind text not null check (source_kind in ('ingestdb', 'obs_aqidb', 'r2', 'api', 'download', 'manual_file', 'none')),
  status text not null check (status in ('planned', 'in_progress', 'complete', 'skipped', 'error', 'dry_run', 'stubbed')),
  rows_read bigint not null default 0,
  rows_written_aqilevels bigint not null default 0,
  objects_written_r2 bigint not null default 0,
  checkpoint_json jsonb,
  error_json jsonb,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists backfill_run_days_run_day_connector_source_uq
  on uk_aq_ops.backfill_run_days (run_id, day_utc, connector_id, source_kind);

create index if not exists backfill_run_days_lookup_idx
  on uk_aq_ops.backfill_run_days (run_mode, day_utc desc, connector_id);

create table if not exists uk_aq_ops.backfill_checkpoints (
  run_mode text not null check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels')),
  day_utc date not null,
  connector_id integer not null,
  source_kind text not null check (source_kind in ('ingestdb', 'obs_aqidb', 'r2', 'api', 'download', 'manual_file', 'none')),
  status text not null check (status in ('complete', 'error', 'dry_run', 'skipped', 'stubbed')),
  rows_read bigint not null default 0,
  rows_written_aqilevels bigint not null default 0,
  objects_written_r2 bigint not null default 0,
  checkpoint_json jsonb,
  error_json jsonb,
  updated_at timestamptz not null default now(),
  primary key (run_mode, day_utc, connector_id)
);

create index if not exists backfill_checkpoints_day_connector_idx
  on uk_aq_ops.backfill_checkpoints (day_utc desc, connector_id);

create table if not exists uk_aq_ops.backfill_errors (
  id bigserial primary key,
  run_id uuid,
  run_mode text not null check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels')),
  day_utc date,
  connector_id integer,
  source_kind text,
  error_json jsonb not null,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now()
);

do $$
declare
  v_table text;
  v_constraint text;
begin
  -- Normalize legacy run mode rows before enforcing renamed check constraints.
  update uk_aq_ops.backfill_runs
  set run_mode = 'source_to_r2'
  where run_mode = 'source_to_all';

  update uk_aq_ops.backfill_run_days
  set run_mode = 'source_to_r2'
  where run_mode = 'source_to_all';

  update uk_aq_ops.backfill_checkpoints
  set run_mode = 'source_to_r2'
  where run_mode = 'source_to_all';

  update uk_aq_ops.backfill_errors
  set run_mode = 'source_to_r2'
  where run_mode = 'source_to_all';

  for v_table in
    select unnest(array[
      'backfill_runs',
      'backfill_run_days',
      'backfill_checkpoints',
      'backfill_errors'
    ])
  loop
    for v_constraint in
      select c.conname
      from pg_constraint c
      join pg_class t on t.oid = c.conrelid
      join pg_namespace n on n.oid = t.relnamespace
      where n.nspname = 'uk_aq_ops'
        and t.relname = v_table
        and c.contype = 'c'
        and pg_get_constraintdef(c.oid) ilike '%run_mode%'
    loop
      execute format(
        'alter table uk_aq_ops.%I drop constraint if exists %I',
        v_table,
        v_constraint
      );
    end loop;
  end loop;

  alter table uk_aq_ops.backfill_runs
    add constraint backfill_runs_run_mode_check
    check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels'));

  alter table uk_aq_ops.backfill_run_days
    add constraint backfill_run_days_run_mode_check
    check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels'));

  alter table uk_aq_ops.backfill_checkpoints
    add constraint backfill_checkpoints_run_mode_check
    check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels'));

  alter table uk_aq_ops.backfill_errors
    add constraint backfill_errors_run_mode_check
    check (run_mode in ('local_to_aqilevels', 'obs_aqi_to_r2', 'source_to_r2', 'r2_history_obs_to_aqilevels'));
end $$;

create index if not exists backfill_errors_run_idx
  on uk_aq_ops.backfill_errors (run_id, created_at desc);

alter table uk_aq_ops.backfill_runs enable row level security;
alter table uk_aq_ops.backfill_run_days enable row level security;
alter table uk_aq_ops.backfill_checkpoints enable row level security;
alter table uk_aq_ops.backfill_errors enable row level security;

do $$
begin
  if not exists (
    select 1
    from pg_policies
    where schemaname = 'uk_aq_ops'
      and tablename = 'backfill_runs'
      and policyname = 'backfill_runs_service_role'
  ) then
    create policy backfill_runs_service_role
      on uk_aq_ops.backfill_runs
      for all
      using ((select auth.role()) = 'service_role')
      with check ((select auth.role()) = 'service_role');
  end if;

  if not exists (
    select 1
    from pg_policies
    where schemaname = 'uk_aq_ops'
      and tablename = 'backfill_run_days'
      and policyname = 'backfill_run_days_service_role'
  ) then
    create policy backfill_run_days_service_role
      on uk_aq_ops.backfill_run_days
      for all
      using ((select auth.role()) = 'service_role')
      with check ((select auth.role()) = 'service_role');
  end if;

  if not exists (
    select 1
    from pg_policies
    where schemaname = 'uk_aq_ops'
      and tablename = 'backfill_checkpoints'
      and policyname = 'backfill_checkpoints_service_role'
  ) then
    create policy backfill_checkpoints_service_role
      on uk_aq_ops.backfill_checkpoints
      for all
      using ((select auth.role()) = 'service_role')
      with check ((select auth.role()) = 'service_role');
  end if;

  if not exists (
    select 1
    from pg_policies
    where schemaname = 'uk_aq_ops'
      and tablename = 'backfill_errors'
      and policyname = 'backfill_errors_service_role'
  ) then
    create policy backfill_errors_service_role
      on uk_aq_ops.backfill_errors
      for all
      using ((select auth.role()) = 'service_role')
      with check ((select auth.role()) = 'service_role');
  end if;
end $$;

grant usage on schema uk_aq_ops to service_role;
grant all on table uk_aq_ops.backfill_runs to service_role;
grant all on table uk_aq_ops.backfill_run_days to service_role;
grant all on table uk_aq_ops.backfill_checkpoints to service_role;
grant all on table uk_aq_ops.backfill_errors to service_role;
grant usage, select on all sequences in schema uk_aq_ops to service_role;

create schema if not exists uk_aq_public;

-- Data API compatibility: expose backfill ledger tables via uk_aq_public
-- when uk_aq_ops schema exposure is unavailable/stale in PostgREST.
create or replace view uk_aq_public.backfill_runs as
select * from uk_aq_ops.backfill_runs;
alter view if exists uk_aq_public.backfill_runs set (security_invoker = true);

create or replace view uk_aq_public.backfill_run_days as
select * from uk_aq_ops.backfill_run_days;
alter view if exists uk_aq_public.backfill_run_days set (security_invoker = true);

create or replace view uk_aq_public.backfill_checkpoints as
select * from uk_aq_ops.backfill_checkpoints;
alter view if exists uk_aq_public.backfill_checkpoints set (security_invoker = true);

create or replace view uk_aq_public.backfill_errors as
select * from uk_aq_ops.backfill_errors;
alter view if exists uk_aq_public.backfill_errors set (security_invoker = true);

revoke all on table uk_aq_public.backfill_runs from public;
revoke all on table uk_aq_public.backfill_runs from anon, authenticated;
grant all on table uk_aq_public.backfill_runs to service_role;

revoke all on table uk_aq_public.backfill_run_days from public;
revoke all on table uk_aq_public.backfill_run_days from anon, authenticated;
grant all on table uk_aq_public.backfill_run_days to service_role;

revoke all on table uk_aq_public.backfill_checkpoints from public;
revoke all on table uk_aq_public.backfill_checkpoints from anon, authenticated;
grant all on table uk_aq_public.backfill_checkpoints to service_role;

revoke all on table uk_aq_public.backfill_errors from public;
revoke all on table uk_aq_public.backfill_errors from anon, authenticated;
grant all on table uk_aq_public.backfill_errors to service_role;

grant usage on schema uk_aq_public to service_role;
