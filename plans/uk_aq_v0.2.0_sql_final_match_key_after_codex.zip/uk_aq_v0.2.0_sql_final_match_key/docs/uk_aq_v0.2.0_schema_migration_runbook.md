# UK AQ v0.2.0 Schema Migration Runbook

## Purpose

This runbook is for revising and testing the UK AQ v0.2.0 SQL files.

The current v0.2.0 SQL draft has the right **canonical target schema**, but the migration sequence must be made safer. The default migration sequence should be **additive and dependency-safe**. The destructive hard cut should be deferred until dependencies are updated and writes are paused.

This work is for the **test database first**, not live beta.

Do not run SQL automatically. Update files only, then report what changed.

---

## Current problem

A Codex review found that the current final migration draft is too aggressive. In particular, `010_rebuild_observations_final.sql` swaps `observations`, removes legacy `timeseries` columns, and renames `station_metadata` while views/RPCs/functions may still depend on the old structure.

The default migration path must not break active views, RPCs, AQI jobs, ingest scripts, RLS, or permissions.

---

## Important rule

Keep these separate:

1. **Canonical v0.2.0 schema files**  
   These can show the final target structure.

2. **Default migration files**  
   These must be additive/test-safe and must not perform destructive hard cuts before dependency analysis and code updates.

3. **Deferred hard-cut files**  
   These can exist, but must be clearly marked as not safe to run until dependencies are fixed and writes are paused.

---

## Final locked v0.2.0 target schema

### connectors

```text
connectors
  id
  connector_code
  label
  display_name
  service_url
  default_network_id
  poll_enabled
  poll_interval_minutes
  poll_window_hours
  scheduler_backend
  config jsonb
  metadata jsonb
  created_at
  updated_at
```

Unique:

```sql
unique (connector_code)
```

### networks

```text
networks
  id
  network_code
  display_name
  ingest_enabled
  public_display_enabled
  default_priority
  metadata jsonb
  created_at
  updated_at
```

Unique:

```sql
unique (network_code)
```

No `display_order` on networks. The website can order networks alphabetically.

### stations

```text
stations
  id
  connector_id
  network_id
  match_id
  priority
  station_ref
  service_ref
  label
  station_name
  station_device_ref
  station_type
  station_exposure
  description
  photo_url
  sensor_height_m
  distance_to_road_m
  is_indoor
  region
  la_code
  la_version
  pcon_code
  pcon_version
  latitude
  longitude
  geometry
  first_seen_at
  last_seen_at
  removed_at
  created_at
  updated_at
```

Unique:

```sql
unique (connector_id, station_ref)
```

Important:

- Keep `service_ref` as a normal column.
- Do not include `service_ref` in unique constraints.
- Do not add `stations.public_display_enabled`.
- Use `removed_at` to exclude stations from public display.
- Do not add a `metadata` column to `stations`, because initial metadata is stored separately.

### station_initial_metadata

```text
station_initial_metadata
  station_id
  attributes jsonb
  captured_at
  created_at
```

Primary key:

```sql
primary key (station_id)
```

Rules:

- Insert once when a station is created or migrated.
- Do not update during normal station refreshes.
- For new ingests, use `on conflict (station_id) do nothing`.
- If a metadata field later needs to be refreshed, promote it to a real column or separate live-status table.

### station_matches

```text
station_matches
  id
  match_key
  match_name
  latitude
  longitude
  geometry
  match_method
  match_confidence
  notes
  metadata jsonb
  created_at
  updated_at
```

Indexes:

```sql
create unique index if not exists station_matches_match_key_uidx
  on station_matches(match_key)
  where match_key is not null;
```

Rules:

- `stations.match_id` is the actual relationship used to match stations.
- `station_matches.match_key` is an optional internal/generated key used by automated matching.
- `match_key` is not an external ID and must not be named `match_ref`.
- Manual matches can leave `match_key` null.
- Automated matching can use values such as `blondon_installation:CLDP0001`.

### observed_properties

```text
observed_properties
  id
  code
  display_name
  domain
  canonical_uom
  display_order
  metadata jsonb
  created_at
  updated_at
```

Unique:

```sql
unique (code)
```

`display_order` belongs here, not on networks.

### timeseries

```text
timeseries
  id
  connector_id
  station_id
  observed_property_id
  timeseries_ref
  service_ref
  label
  uom
  first_value_at
  last_value_at
  last_value
  status
  metadata jsonb
  created_at
  updated_at
  ended_at
```

Unique:

```sql
unique (connector_id, timeseries_ref)
```

Important:

- Keep `service_ref` as a normal column.
- Do not include `service_ref` in unique constraints.
- Do not add `network_id`.
- Do not add `phenomenon_id`.
- Use direct `timeseries.observed_property_id -> observed_properties.id`.
- Source-specific species/phenomenon details can live in `timeseries.metadata`.

### observations

```text
observations
  timeseries_id
  observed_at
  value
  status
  metadata jsonb
  created_at
```

Primary key:

```sql
primary key (timeseries_id, observed_at)
```

Important:

- Do not add `connector_id`.
- Do not add `network_id`.
- Observations link to connector/network through:
  - `observations -> timeseries -> stations -> connectors`
  - `observations -> timeseries -> stations -> networks`

### uk_aq_ingest_runs

Keep the existing table name:

```text
uk_aq_ingest_runs
  id
  connector_id
  connector_code
  network_id
  network_code
  run_started_at
  run_ended_at
  run_status
  run_message
  last_observed_at
  stations_updated
  observations_upserted
  timeseries_updated
  series_polled
  response_status
  response_payload
  created_at
```

Rules:

- `network_id` and `network_code` are nullable.
- Keep both `connector_id` and `connector_code`.
- Add both `network_id` and `network_code`.

---

## Connector and network decisions

### Connector codes

Use:

```text
uk_air_sos
blondon_communities
blondon_nodes
openaq
sensorcommunity
```

Migration rule:

```text
old connector_code = breathelondon
becomes blondon_communities
```

### Connector labels/display names

Use connector identity for connector display names.

Important:

```text
UK-AIR SOS
```

not:

```text
UK-AIR-SOS
```

and not:

```text
GOV.UK AURN
```

`GOV.UK AURN` belongs in `networks.display_name`, not connector display.

### Initial networks

Seed at least:

```text
gov_uk_aurn        GOV.UK AURN        public_display_enabled true
breathelondon      Breathe London     public_display_enabled true
openaq             OpenAQ             public_display_enabled false
sensorcommunity    Sensor.Community   public_display_enabled false
laqn               LAQN               public_display_enabled false
```

Initial public display should be only:

```text
GOV.UK AURN
Breathe London
```

---

## Breathe London Nodes notes

Breathe London Nodes has been smoke-tested successfully.

Details:

```text
base URL: https://breathe-london-7x54d7qf.ew.gateway.dev
API key env var: BLONDON_API_KEY
auth header: X-API-KEY
endpoints: /ListSensors and /SensorData
station ref: SiteCode, e.g. BL0032
dedupe bridge to Communities: InstallationCode, e.g. CLDP0001
species: PM25 and NO2
observation value: ScaledValue
observation timestamp: DateTime
unit: Units
status: RatificationStatus
```

Skip rows where `ScaledValue` is null.

Automated matching rule to support later:

```text
if blondon_nodes InstallationCode = blondon_communities station_ref
then use station_matches.match_key = blondon_installation:<InstallationCode>
```

Important metadata mapping:

- `device_code` / `DeviceCode` can populate `stations.station_device_ref`.
- `InstallationCode` should be preserved in initial metadata and later used as the Nodes-to-Communities match bridge.
- Do not treat `InstallationCode` as the device code.

---

## UK-AIR SOS placeholder row

Current placeholder row:

```text
id: 3291
station_ref: 9999999999
label: GB_SamplingFeature_missingFOI
station_name: GB_SamplingFeature_missingFOI
metadata:
  is_placeholder: true
  exclude_from_ui: true
  placeholder_source: uk_air_sos
```

Migration rule:

- Migrate the row.
- Set `removed_at` if it is null.
- Do not add a placeholder column.

---

## Things deliberately not included

Do not create:

```text
connector_checkpoints
station_network_memberships
uk_aq_networks
public_stations
public_station_sources
public_timeseries_selection
```

Keep connector/network-specific checkpoint tables where needed.

---

## Required SQL file strategy

### Canonical schema files

Keep final target schema files in:

```text
schemas/v0.2.0/
```

Suggested files:

```text
001_core_schema.sql
002_aqilevels_schema.sql
003_connector_specific_checkpoint_tables.sql
004_public_views.sql
005_rpc.sql
006_seed_core.sql
007_security.sql
```

The canonical schema can show the final v0.2.0 structure.

### Migration files

Keep migration files in:

```text
migrations/v0.2.0/
```

The default migration sequence must be additive and dependency-safe.

Do not include destructive hard cuts in the normal run order.

---

## Required revision to the current migration set

Revise the existing v0.2.0 migration set using these rules.

### 1. Defer the hard cut

Remove or disable `010_rebuild_observations_final.sql` from the default ordered migration sequence.

Rename it to something like:

```text
900_hard_cut_observations_after_dependencies.sql
```

Add a large header:

```text
DO NOT RUN until RPCs, views, AQI functions, ingest scripts, permissions and RLS have been updated and writes are paused.
```

This hard-cut script must not be part of the normal migration sequence yet.

### 2. Add dependency report SQL checks

Create:

```text
010_dependency_report_sql_checks.sql
```

This should query `pg_depend`, `pg_proc`, `pg_views`, `pg_matviews`, `information_schema`, or other relevant Postgres catalog tables to find objects referencing old schema elements.

Check for dependencies on:

```text
observations.connector_id
timeseries.phenomenon_id
timeseries.offering_id
timeseries.feature_id
timeseries.procedure_id
timeseries.category_id
stations.category_id
station_metadata
phenomena
station_network_memberships
uk_aq_networks
old observations primary key assumptions
```

This file should produce a report, not drop or alter objects.

### 3. Keep additive migrations

Keep or create additive migrations for:

```text
networks
station_matches with match_key
station_initial_metadata
stations.network_id
stations.match_id
stations.priority
observed_properties.display_order
timeseries.observed_property_id
uk_aq_ingest_runs.network_id
uk_aq_ingest_runs.network_code
observations.status if missing
observations.metadata if missing
```

Do not drop legacy columns in the default migration sequence.

### 4. Fix timeseries observed property migration

Current issue: the migration blocks before diagnostics if there are unmapped timeseries.

Split it into safer phases:

```text
005a_migrate_timeseries_observed_properties.sql
005b_validate_timeseries_observed_properties.sql
905_enforce_timeseries_observed_property_not_null.sql
```

Rules:

- `005a` should backfill what it can.
- `005b` should list unmapped timeseries clearly.
- Do not set `observed_property_id not null` until mappings are complete.
- `905` can enforce not-null later, after dependencies and mappings are fixed.

### 5. Fix Breathe London dedupe bridge handling

Ensure station migration:

- uses `device_code` / `DeviceCode` for `station_device_ref`
- preserves `InstallationCode` in `station_initial_metadata.attributes`
- includes notes/TODO for future automated matching with:
  - `station_matches.match_key = blondon_installation:<InstallationCode>`

### 6. Fix UK-AIR SOS display text

Use:

```text
UK-AIR SOS
```

not:

```text
UK-AIR-SOS
```

### 7. Preserve scheduler backend

Do not silently change existing connector `scheduler_backend` values during migration.

On conflict, preserve existing `scheduler_backend` unless a deliberate change is required.

### 8. Add RLS/grants warnings

Any future replacement-table migration must recreate:

```text
RLS enabled state
RLS policies
grants
owner if needed
comments if needed
indexes
triggers
```

For now, do not replace `observations` in the default sequence.

### 9. Add concurrency warnings

The future hard cut must:

- pause writes first
- be run in a maintenance window
- run in an explicit transaction where possible
- lock the relevant tables before copying/swapping
- fail if rows would be lost
- fail on key collisions instead of using `distinct on`
- fail on null `timeseries_id` rows instead of filtering them silently
- compare legacy/new observation counts
- recreate RLS/grants/policies
- be rerunnable or explicitly non-rerunnable with clear prechecks

### 10. Update notes

Update:

```text
docs/v0.2.0_schema_migration_notes.md
```

Explain:

- canonical schema is the final target
- default migrations are phase 1 additive
- hard cut is deliberately deferred
- dependency analysis is required before hard cut
- code/RPC/view/AQI updates are required before hard cut
- writes must be paused for the hard cut

---

## Dependency check report

Also create a markdown report:

```text
docs/v0.2.0_dependency_check.md
```

Search at least these repos if present locally:

```text
uk-aq-schema
uk-aq-ingest
uk-aq
uk-aq-ops
```

Search SQL, Python, JS, workflow and docs files for old schema dependencies.

Look for references to:

### Old/deprecated tables

```text
station_metadata
station_network_memberships
uk_aq_networks
phenomena
offerings
features
procedures
categories
reference_values
connector_checkpoints
public_stations
public_station_sources
public_timeseries_selection
```

### Old/deprecated columns

```text
observations.connector_id
timeseries.phenomenon_id
timeseries.offering_id
timeseries.feature_id
timeseries.procedure_id
timeseries.category_id
stations.category_id
stations.public_display_enabled
stations.metadata
group_id
source_station_ref
```

### Likely affected objects

```text
schemas/**/uk_aq_public_views.sql
schemas/**/uk_aq_rpc.sql
AQI functions/views
ingest upsert functions
Breathe London ingest
UK-AIR SOS station/timeseries sync
OpenAQ ingest
Sensor.Community ingest
AQI hourly/daily/monthly reconcile scripts
website public views/RPCs
map data RPCs
chart/history RPCs
station list queries
network filter logic
```

Report each dependency with:

```text
file path
line number or nearby function name
old table/column/function referenced
why it breaks or might break under v0.2.0
suggested v0.2.0 replacement
severity: blocker, high, medium, low
```

Suggested replacement guidance:

```text
station_metadata -> station_initial_metadata only for initial metadata reads
do not update station_initial_metadata during refreshes
timeseries.phenomenon_id -> timeseries.observed_property_id
phenomena joins -> observed_properties joins
station_network_memberships/uk_aq_networks -> stations.network_id -> networks.id
observations.connector_id -> observations.timeseries_id -> timeseries.connector_id if needed
old observation conflict key -> primary key (timeseries_id, observed_at)
public network visibility -> networks.public_display_enabled
station exclusion -> stations.removed_at
dedupe display -> stations.match_id / station_matches / stations.priority
```

Report structure:

```text
1. Summary
2. Blockers
3. High-risk public/API dependencies
4. Ingest dependencies
5. AQI dependencies
6. Website dependencies
7. Low-risk/archive/docs references
8. Recommended fix order
9. Open questions
```

---

## Expected output from Codex

1. Updated SQL files.
2. Updated notes markdown.
3. New dependency report markdown.
4. No SQL executed.
5. No destructive migration in the default run order.
6. Clear list of files changed.
7. Clear explanation of anything deferred to the hard-cut phase.

